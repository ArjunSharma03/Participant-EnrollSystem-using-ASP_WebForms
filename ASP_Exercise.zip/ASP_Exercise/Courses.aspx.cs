﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ASP_Exercise
{
    public partial class Courses : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserId"] != null)
                lblSession.Text = Session["UserId"].ToString();
            if (Request.QueryString["User"] != null)
                lblquery.Text = Request.QueryString["User"];
        }
    }
}
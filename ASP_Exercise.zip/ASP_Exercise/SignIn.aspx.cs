﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAL_ParticipantsEnroll;
using System.Data.SqlClient;

namespace ASP_Exercise
{
    public partial class SignIn : System.Web.UI.Page
    {
        ParticipantsEnrollData pobj = null;
        SignUpModel sobj = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            pobj = new ParticipantsEnrollData();
            sobj = new SignUpModel();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            sobj.UserId = txtUserId.Text;
            sobj.UserPwd = txtPwd.Text;
            if(pobj.SignDetails(sobj))
            {
                Label1.Text = "Login Success";
            Session["UserId"] = txtUserId.Text;
            }
            else
            {
                Label1.Text = "User not exists please do register first";
            }
        }
    }
}
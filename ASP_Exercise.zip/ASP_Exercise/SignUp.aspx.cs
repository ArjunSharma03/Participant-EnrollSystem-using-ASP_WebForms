﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DAL_ParticipantsEnroll;
using System.Data.SqlClient;

namespace ASP_Exercise
{
    public partial class SignUp : System.Web.UI.Page
    {
        ParticipantsEnrollData pobj = null;
        SignUpModel sobj = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            pobj = new ParticipantsEnrollData();
            sobj = new SignUpModel();

            if(!IsPostBack)
            {
            FillCourses();
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            sobj.UserId = txtUserId.Text;
            sobj.UserPwd = txtPwd.Text;
            sobj.CourseName = ddlCourse.SelectedItem.Value;
            if (pobj.AddSignUpDetails(sobj))
            {
                lblMessage.Text = "Data Saved";
            }
            else
            {
                lblMessage.Text = "UserId already exists,Data not Saved ";
            }

        }
        private void FillCourses()
        {
            SqlDataReader drCourse = pobj.FillCourseDropDown();

            ddlCourse.DataSource = drCourse;
            ddlCourse.DataValueField = "CourseId";
            ddlCourse.DataTextField = "CourseName";
            ddlCourse.DataBind();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace DAL_ParticipantsEnroll
{
    public class ParticipantsEnrollData
    {
        string cs = "server=;database=ParticipantsSystemDB;integrated security=true";

        public SqlDataReader FillCourseDropDown()
        {
            SqlConnection con = new SqlConnection(cs);
            SqlCommand cmd = new SqlCommand("Select * from CourseMaster", con);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();

            return dr;
        }

        public bool AddSignUpDetails(SignUpModel obj)
        {
            bool check = false;
            string CS = "server=;database=ParticipantsSystemDB;integrated security=true";
            SqlConnection con = new SqlConnection(CS);          
            SqlCommand cmdcheck = new SqlCommand("select count(*) from ParticipantsRegistration where UserId="+obj.UserId, con);
            con.Open();
            int count = Convert.ToInt32(cmdcheck.ExecuteScalar());
            if (count > 0)
            {
                con.Close();
                check = false;
                return check;
            }
            else
            {
                SqlCommand cmd = new SqlCommand("usp_SaveParticipantsEnrollment", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@userId", obj.UserId);
                cmd.Parameters.AddWithValue("@userPwd", obj.UserPwd);
                cmd.Parameters.AddWithValue("@Course", obj.CourseName);
                int affectedRows = cmd.ExecuteNonQuery();
                if (affectedRows > 0)
                {
                    con.Close();
                    check = true;
                    return check;
                }
                else
                {
                    con.Close();
                    check = false;
                    return check;
                }
            }
        }

        public bool SignDetails(SignUpModel obj)
        {
            
            string CS = "server=;database=ParticipantsSystemDB;integrated security=true";
            SqlConnection con = new SqlConnection(CS);
            SqlCommand cmdcheck = new SqlCommand("select count(*) from ParticipantsRegistration where UserId=" + obj.UserId, con);
            con.Open();
            int count = Convert.ToInt32(cmdcheck.ExecuteScalar());
            if (count > 0)
            {
                con.Close();
                return true;
            }
            else
            {
                return false;
            }
        }
    }

        public class SignUpModel
        {
            public string UserId { get; set; }
            public string UserPwd { get; set; }
            public DateTime RegistrationDate { get; set; }
            public string CourseName { get; set; }
        }
    }

